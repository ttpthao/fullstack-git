import {Component}  from "angular2/core";
@Component({
    selector: "roles",
    templateUrl: "app/modules/usermanagement/permission/permissions.html",
})
export class Permissions {
    constructor() {}
}