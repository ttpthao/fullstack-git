import {Component}  from "angular2/core";
@Component({
    selector: "groups",
    templateUrl: "app/modules/usermanagement/group/groups.html",
})
export class Groups {
    constructor() {}
}