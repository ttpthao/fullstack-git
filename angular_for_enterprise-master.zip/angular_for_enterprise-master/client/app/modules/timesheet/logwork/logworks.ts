import {Component}  from "angular2/core";
@Component({
    selector: "logworks",
    templateUrl: "app/modules/timesheet/logwork/logworks.html",
})
export class LogWorks {
    constructor() {}
}