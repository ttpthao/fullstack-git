import {Component}  from "angular2/core";
@Component({
    selector: "work",
    templateUrl: "app/modules/timesheet/work/works.html",
})
export class Works {
    constructor() {}
}