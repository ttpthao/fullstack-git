import {Component}  from "angular2/core";
@Component({
    selector: "tasks",
    templateUrl: "app/modules/timesheet/task/tasks.html",
})
export class Tasks {
    constructor() {}
}