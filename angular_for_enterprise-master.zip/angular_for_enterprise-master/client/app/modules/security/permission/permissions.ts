import {Component} from "angular2/core";
import {PageActions, Grid} from "../../../common/directive";
import {PageAction} from "../../../common/models/ui";
import {PermissionsModel} from "./permissionsModel";
import {BasePage} from "../../../common/models/ui";
import permissionService from "../_share/services/permissionService";

@Component({
    templateUrl: "app/modules/security/permission/permissions.html",
    directives:[PageActions, Grid]
})

export class Permissions extends BasePage{
    public model: PermissionsModel = new PermissionsModel();
    constructor(){
        super();
        let self: Permissions = this;
        this.model.addAction(new PageAction("btnAddPermission", 
        "security.permissions.addPermission", ()=> self.onAddPermissionClicked()));
        this.loadPermissions();
    }

    public onPermissionDeleteClicked(perItem: any){
        let self: Permissions = this;
        permissionService.delete(perItem.item.id).then(function(){
            self.loadPermissions();
        });
    }

    private loadPermissions(){
        let self: Permissions = this;
        permissionService.loadPermissions().then(function(perItems: Array<any>){
            self.model.import(perItems);
        });
    }

    private onAddPermissionClicked(){
        console.log("onAddPermissionClicked");
    }
}