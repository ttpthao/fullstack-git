import {JsonHeaders} from "../../../../common/models/http";
import configHelper from "../../../../common/helpers/configHelper";
let permissionService={
    loadPermissions: loadPermissions,
    delete: remove
};
export default permissionService;
function loadPermissions(){
    var url= String.format("{0}/permissions", configHelper.getAppConfig().api.baseUrl);
    var connector = window.ioc.resolve("IConnector");
    var jsonHeader = new JsonHeaders();
    return connector.get(url, jsonHeader);
}
function remove(id: any){
    var url = String.format("{0}/permissions/{1}", configHelper.getAppConfig().api.baseUrl, id);
    var connector = window.ioc.resolve("IConnector");
    var jsonHeader = new JsonHeaders();
    return connector.delete(url, jsonHeader);
}