import {IModule, MenuItem} from "../models/layout";
let moduleHelper = {
    loadModuleConfig: loadModuleConfig
};
export default moduleHelper;
function loadModuleConfig( moduleBasePath: string ) {
    let configPath = moduleBasePath + "/config/module";
}