import {Component, OnInit, Input}  from "angular2/core";
import {ROUTER_DIRECTIVES} from "angular2/router";
@Component({
    selector: "sidebar-footer",
    templateUrl: "app/common/layouts/default/directives/layout/sidebarFooter.html",
    directives: [ROUTER_DIRECTIVES]
})
export class SidebarFooter {
}