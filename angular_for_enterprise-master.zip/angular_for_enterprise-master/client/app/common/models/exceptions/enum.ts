export const ValidationMode = {
    Invalid: "validation invalid",
    Valid: "validation valid"
};
