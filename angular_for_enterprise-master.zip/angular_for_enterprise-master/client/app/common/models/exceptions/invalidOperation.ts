export class InvalidOperation {
    constructor(key: string, msg: string = "") {
        // super(key, msg);
    }
} 