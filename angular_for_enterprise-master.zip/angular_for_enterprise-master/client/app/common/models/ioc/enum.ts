export enum IoCInstanceType {
    Transient,
    Singleton
}