export class KeyNamePair {
    public key: string;
    public value: string;
    constructor(key: string, value: string) {
        this.key = key;
        this.value = value;
    }
}