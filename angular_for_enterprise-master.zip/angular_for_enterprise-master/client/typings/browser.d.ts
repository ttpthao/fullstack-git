/// <reference path="browser/ambient/es6-shim/index.d.ts" />
/// <reference path="browser/ambient/jasmine/index.d.ts" />
