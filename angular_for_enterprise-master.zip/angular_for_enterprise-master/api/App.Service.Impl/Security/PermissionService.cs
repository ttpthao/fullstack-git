﻿using App.Common.DI;
using App.Repository.Security;
using App.Service.Security;
using System.Collections.Generic;
using App.Entity.Security;
using System;
using App.Context;
using App.Common.Data;
using App.Common;
using App.Common.Validation;

namespace App.Service.Impl.Security
{
    public class PermissionService: IPermissionService
    {
        public IList<PermissionListItem> GetPermissions()
        {
            IPermissionRepository perRepo = IoC.Container.Resolve<IPermissionRepository>();
            return perRepo.GetItems<PermissionListItem>();
        }

        public void DeletePermission(string itemID)
        {
            ValidateForDelete(itemID);
            using (IUnitOfWork uow = new UnitOfWork(new AppDbContext(IOMode.Write)))
            {
                IPermissionRepository perRepo = IoC.Container.Resolve<IPermissionRepository>(uow);
                perRepo.Delete(itemID);
                uow.Commit();
            }
        }

        private void ValidateForDelete(string itemID)
        {
            if (string.IsNullOrWhiteSpace(itemID))
            {
                throw new ValidationException("security.deletePermissions.invalid");
            }
            Guid id;
            if (!Guid.TryParse(itemID, out id))
            {
                throw new ValidationException("security.deletePermissions.invalid");
            }
        }
    }
}
