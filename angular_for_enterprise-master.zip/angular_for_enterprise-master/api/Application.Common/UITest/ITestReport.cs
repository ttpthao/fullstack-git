﻿namespace App.Common.UITest
{
    public interface ITestReport
    {
        TestReportType Type { get; set; }
    }
}
