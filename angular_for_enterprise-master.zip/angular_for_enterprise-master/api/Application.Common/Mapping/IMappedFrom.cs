﻿
namespace App.Common.Mapping
{
    public interface IMappedFrom<T>
    {
    }
}
