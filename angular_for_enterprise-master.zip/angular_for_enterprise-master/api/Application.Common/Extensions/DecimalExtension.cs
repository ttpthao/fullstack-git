﻿
using System.Globalization;
using App.Common.Configurations;

namespace App.Common.Extensions
{
    public static class DecimalExtension
    {
      
    }
}
