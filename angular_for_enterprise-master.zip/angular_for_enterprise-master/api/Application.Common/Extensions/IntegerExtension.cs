﻿using System;
using App.Common.Configurations;

namespace App.Common.Extensions
{
    public static partial class IntegerExtension
    {
      
    }
}
