﻿
using System;

namespace App.Common.Extensions
{
    public static class IntExtension
    {
       
    }
}
