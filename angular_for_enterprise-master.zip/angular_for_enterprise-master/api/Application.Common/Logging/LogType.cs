﻿namespace App.Common.Logging
{
    public enum LogType
    {
        Info,
        Warn,
        Error
    }
}
