﻿namespace Application.Common.Helpers.Html.Icon
{
    public enum IconType
    {
        Delete,
        Edit
    }
}
