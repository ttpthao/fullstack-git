﻿using System.Web.Http.Controllers;
namespace App.Common.Authorize
{
    public interface IUserLoginAuthorization : IAuthorization
    {
        
    }
}
