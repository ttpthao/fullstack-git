﻿namespace Omega.Common.Authorization
{
    public interface ICustomerLoginAuthorization : IAuthorization
    {
    }
}
