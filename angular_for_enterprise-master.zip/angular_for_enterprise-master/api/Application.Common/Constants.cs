﻿
namespace App.Common
{
    public static class Constants
    {
        public const string AUTHENTICATION_TOKEN = "AuthenticationToken";


        public const string APPLICATION_NAMESPACE_START_WITH = "App.";

        public const string RESOURCE_KEY_PATTERN = "{0}!!{1}";
    }
}