﻿namespace App.Common.Tasks
{
    public interface IServiceContainerConfiguredTask<TArgument> : IBaseTask<TArgument>
    {
    }
}
