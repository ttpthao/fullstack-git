﻿namespace App.Common.Tasks
{
    using System.Web;
    public interface IApplicationRequestStartedTask<TArgument> : IBaseTask<TArgument>
    {
    }
}
