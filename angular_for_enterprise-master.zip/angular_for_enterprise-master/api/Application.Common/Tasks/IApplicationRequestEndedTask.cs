﻿namespace App.Common.Tasks
{
    using System.Web;
    public interface IApplicationRequestEndedTask<TArgument> : IBaseTask<TArgument>
    {
    }
}
