﻿namespace App.Common.Tasks
{
    using System.Web;
    public interface IUnHandledErrorTask<TArgument> : IBaseTask<TArgument>
    {
    }
}
