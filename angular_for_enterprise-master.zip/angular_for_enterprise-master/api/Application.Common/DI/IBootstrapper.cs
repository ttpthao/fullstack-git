﻿namespace App.Common.DI
{
    using App.Common.Tasks;
    public interface IBootstrapper : IBaseTask<IBaseContainer>
    {
    }
}
