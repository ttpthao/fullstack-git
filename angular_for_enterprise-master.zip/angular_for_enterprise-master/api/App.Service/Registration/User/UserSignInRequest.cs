﻿namespace App.Service.Registration.User
{
    public class UserSignInRequest
    {
        public string Email { get; set; }
        public string Pwd { get; set; }
    }
}
