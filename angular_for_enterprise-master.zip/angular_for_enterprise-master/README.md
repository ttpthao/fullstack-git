# angular_for_enterprise
introduce how to organise the angular2 (ts) using with webapi for enterprise application
For mỏe information about the code, please contact me on skype (tranthanhtu83)